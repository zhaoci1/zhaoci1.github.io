module.exports= {
    port:3306,
    host:'127.0.0.1',
    user:'root',
    password:'root',
    database:'school'
}