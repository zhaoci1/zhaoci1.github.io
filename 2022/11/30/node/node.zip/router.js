
var url = require('url')
var path = require('path')
var fs = require('fs')

var _ = require('underscore')
var model = require('./mysql')

module.exports = function (req, res) {
    var urlObj = url.parse(req.url, true)
    var pathname = urlObj.pathname
    var method = req.method.toLowerCase()

    req.query = urlObj.query

    if (pathname == '/' && method == 'get') {
        fs.readFile(path.join(__dirname, 'view', 'index.html'), function (err, data) {
            if (err) {
                return res.end(err.message)
            }
            model.findResumeBasicInformations(function (err, results) {
                // console.log(results)
                var compiled = _.template(data.toString())
                var htmlStr = compiled({
                    basicInformations: results
                })
                res.setHeader('Content-Type', 'text/html;charset=utf-8')
                res.end(htmlStr)
            })
        })
    } else if (['/public/', '/node_modules/'].findIndex(item => pathname.startsWith(item)) >= 0 && method == 'get') {
        fs.readFile(path.join(__dirname, pathname), function (err, data) {
            if (err) {
                return res.end(err.message)
            }
            res.end(data)
        })

    } else if (['/view/index2.html'].findIndex(item => pathname.startsWith(item)) >= 0 && method == 'get') {
        fs.readFile(path.join(__dirname, pathname), function (err, data) {
            if (err) {
                return res.end(err.message)
            }
            model.findResumeInformations(urlObj.query.id, function (err, results) {
                var compiled = _.template(data.toString())
                var htmlStr = compiled({
                    basicInformations: results[0],
                    personalCapability: results[1],
                    practicalExperience: results[2],
                    honorCertificate: results[3]
                })
                res.setHeader('Content-Type', 'text/html;charset=utf-8')
                res.end(htmlStr)
            })


        })
    }


}