var mysql = require('mysql')
var config = require('./config')

var pool = mysql.createPool({
    multipleStatements: true,
    host: config.host,
    user: config.user,
    password: config.password,
    database: config.database
})
module.exports.findResumeBasicInformations = function (callback) {
    pool.getConnection(function (err, conn) {
        if (err) {
            return callback("连接池连接失败！" + err, null)
        }
        var sql = `SELECT * FROM ResumeBasicInformationTable ORDER BY id LIMIT 5;
               `
        conn.query(sql, function (err, results) {
            conn.release()
            if (err) {
                return callback("查询失败！" + err, null)
            }
            callback(null, results)
        })
    })
}
module.exports.findResumeInformations = function (id, callback) {
    pool.getConnection(function (err, conn) {
        if (err) {
            return callback("连接池连接失败！" + err, null)
        }
        var sql = `SELECT * FROM ResumeBasicInformationTable WHERE id=? ;
        SELECT * FROM PersonalCapabilityTable WHERE id=? ;
        SELECT * FROM PracticalExperienceTable WHERE id=? ;
        SELECT * FROM HonorCertificateTable WHERE id=? ;
        `
        conn.query(sql, [id, id, id, id], function (err, results) {
            conn.release()
            if (err) {
                return callback("查询失败！" + err, null)
            }
            callback(null, results)
        })


    })
}