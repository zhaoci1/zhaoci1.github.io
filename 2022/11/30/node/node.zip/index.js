var http=require('http')
var config=require('./config')
var router=require('./router')

var server=http.createServer()

server.on('request',function (req,res) {
    router(req,res)
})

server.listen(3000,'127.0.0.1',function () {
    console.log('启动成功')
})