-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- 主机： 127.0.0.1
-- 生成日期： 2022-11-19 12:24:06
-- 服务器版本： 10.4.13-MariaDB
-- PHP 版本： 7.4.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 数据库： `resume`
--

-- --------------------------------------------------------

--
-- 表的结构 `honorcertificatetable`
--

CREATE TABLE `honorcertificatetable` (
  `id` int(11) NOT NULL,
  `item` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='荣誉证明表';

--
-- 转存表中的数据 `honorcertificatetable`
--

INSERT INTO `honorcertificatetable` (`id`, `item`) VALUES
(1, '三好学生'),
(1, '优秀干部'),
(2, '助人为乐');

-- --------------------------------------------------------

--
-- 表的结构 `personalcapabilitytable`
--

CREATE TABLE `personalcapabilitytable` (
  `id` int(11) NOT NULL,
  `item` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='个人能力表';

--
-- 转存表中的数据 `personalcapabilitytable`
--

INSERT INTO `personalcapabilitytable` (`id`, `item`) VALUES
(1, 'JS'),
(1, 'HTML'),
(1, 'node.js');

-- --------------------------------------------------------

--
-- 表的结构 `practicalexperiencetable`
--

CREATE TABLE `practicalexperiencetable` (
  `id` int(11) NOT NULL,
  `item` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='实践经历表';

--
-- 转存表中的数据 `practicalexperiencetable`
--

INSERT INTO `practicalexperiencetable` (`id`, `item`) VALUES
(1, '蓝桥杯'),
(1, '机器人大赛'),
(2, '大数据比赛');

-- --------------------------------------------------------

--
-- 表的结构 `resumebasicinformationtable`
--

CREATE TABLE `resumebasicinformationtable` (
  `id` int(11) NOT NULL,
  `name` varchar(10) NOT NULL COMMENT '姓名',
  `major` varchar(10) NOT NULL COMMENT '专业',
  `workexperience` double NOT NULL COMMENT '工作经验年限',
  `situation` varchar(10) NOT NULL COMMENT '工作岗位',
  `photo` varchar(50) NOT NULL,
  `birth` varchar(10) DEFAULT NULL COMMENT '出生年月',
  `graduatedfrom` varchar(50) DEFAULT NULL COMMENT '毕业院校',
  `GraduationDate` varchar(10) DEFAULT NULL COMMENT '毕业日期'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='简历基本信息表';

--
-- 转存表中的数据 `resumebasicinformationtable`
--

INSERT INTO `resumebasicinformationtable` (`id`, `name`, `major`, `workexperience`, `situation`, `photo`, `birth`, `graduatedfrom`, `GraduationDate`) VALUES
(1, '张三', '计应', 0.5, '前端开发', '1.webp', '2003-10-01', '武汉城市职业学院', '2023-08-01'),
(2, '李四', '计科', 1.5, '后端开发', '2.webp', '2002-09-01', '武汉东湖学院', '2023-08-01'),
(3, '王五', '网安', 0.5, '网管', '3.webp', '2003-09-01', '武汉软件职业学院', '2023-08-01'),
(4, '赵六', '大数据', 0, '算法工程师', '4.webp', '2003-10-01', '武汉城市职业学院', '2023-08-01');

--
-- 转储表的索引
--

--
-- 表的索引 `honorcertificatetable`
--
ALTER TABLE `honorcertificatetable`
  ADD KEY `id` (`id`);

--
-- 表的索引 `personalcapabilityt